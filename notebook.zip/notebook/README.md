# notes_android
Simple notepad, programming language Kotlin
